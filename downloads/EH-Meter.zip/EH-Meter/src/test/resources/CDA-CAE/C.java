interface I {
	int abc(String s);
}

class A implements I {
	public int abc(String s){
		return 0;
	}
	
	int def(String s){
		return 1;
	}
}

class B implements I {
	public int abc(String s){
		return 1;
	}
	
	int def(String s){
		return 1;
	}
}

class C {
	C(int i){	
	}
	int ghi() {
		return 3;
	}
	void xyz() {
		ghi();
	}
}

interface ID {
	void dMethod();
}
//class D {}

aspect A1 {
	pointcut i() : execution(int I.abc(String));
	before() : i () {}
}

aspect A2 {
	pointcut ghi() : call(* ghi(..));
	before() : ghi () {}
	
	void simpleMethod() {}
}

aspect A3 {
	pointcut all() : execution(* *(..));
	before() : all() {}
}

aspect A4 {
	int C.xxx;
	int B.init() { return 10; }
}

aspect A5 {
	declare parents: C extends B;
}

aspect A6 {
	declare parents: D implements ID;

	pointcut p1() : execution(* ID.dMethod(..));
	before() : p1() {}

	public void D.dMethod() {}
	public void ID.dMethod() {}
}
