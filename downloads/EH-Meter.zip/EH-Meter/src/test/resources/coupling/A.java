


public class A {
	private int a;
	public int x;
	static int[] tab = new int[10];
	
	public A(int a){
		this.a = a;
	}
	public void abc(int b) {
		a = 1 + b;
		this.a ++;
		
		abc(1);
	}
}

class B {
	public int z;

	public void bcd() {
		A a = new A(3);
		a.abc(10);
	}
}

class C {
	public void cde() {
		B b = new B();
		b.z = 10;
		
		D d = new D();
		d.a.abc(b.z);
		d.a.x = 0;
		
		int[] x = new int[10];
	}
}

class D {
	public A a = new A(0);
	static A aa = new A(3);

	static int foo() {
		D.aa.x = 1;
		D.foo();

		return 0;
	}
}

class E {

	void xyz() {
		D.aa.abc(10);
		D.foo();
		
		System.out.println(D.aa.tab.length);
	}
	
	enum EE {
		X1, X2;
	}
}

enum En {
	VAL1, VAL2;
}


class Intro {
}

aspect Aspect {
	public int Intro.x;
	public void Intro.introMethod() {
		D.foo();
		AClass.var = 1;
	}
}

class AClass {
	static public int var;
}

class CallToIntro {
	void m(Intro intro) {
		intro.introMethod();
		intro.x = 1;
	}
}
