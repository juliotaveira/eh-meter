class P0 {
	void abc() {}
}

class P1 extends P0 {
	void abc() {}
}

class T {
	P0 getP(){
		return new P1();
	}
	void test() {
		P0 p = getP();
		p.abc();
		
		getP().abc();
	}
}