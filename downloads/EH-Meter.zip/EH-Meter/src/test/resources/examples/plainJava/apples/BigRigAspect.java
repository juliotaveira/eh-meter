
package apples;

/**
 * This aspect represents upacking apples after an airplane trip.
 *
 * @author	Mik Kersten
 * @version	$Version$
 */

public class BigRigAspect extends TransportAspect
{
    /**
      * Default constructor
      */
    public BigRigAspect() {}
}
