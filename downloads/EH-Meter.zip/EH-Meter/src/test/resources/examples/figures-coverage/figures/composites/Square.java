
package figures.composites;

class Square { 
   private String name = "Square";
}
