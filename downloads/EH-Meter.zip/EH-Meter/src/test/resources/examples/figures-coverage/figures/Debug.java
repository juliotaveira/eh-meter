
package figures;

aspect Debug {

}

