
package figures.composites;

class Line { }

class BoundedLine extends Line { } 
