
package figures;

public interface FigureElement extends Element {

    public void incrXY(int dx, int dy);
}

interface Element { }
