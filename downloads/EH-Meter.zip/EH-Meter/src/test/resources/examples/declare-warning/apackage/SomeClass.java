package apackage;

public class SomeClass {
	
	int x;
	
	public SomeClass() {
		init();  // line 6	
		x = 3;
	}
	
	public void init() {
	}
	
}