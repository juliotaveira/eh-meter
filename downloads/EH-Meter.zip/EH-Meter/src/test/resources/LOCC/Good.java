interface A {
	void foo();
}



public class Good extends AbstractGood implements A {

  protected Good() {
	
  }
  static int z = 3;
  static {
	  z++;
  }
  
  public void foo() {
    int i = 0; i += 1; i += 2;
  }
  
  public String barbar(String arg1, 
  			String arg2,
  			String arg3,
  			String arg4, 
  			String arg5,
  			String arg6){
  	while(arg1 != null) {
  		for(int i = 0 ; i < 10 ; i++) ;
  	}
  	 return arg6;
  }

  int x = 3;
  private String bar1 = "first line " +
  	"second line";
}

aspect As implements A {
  before(): call(* *(..)) {
    System.out.println("");
  }

  public void foo() {}
  public String Good.foo;
  public String Good.foop() { return "";}
}


