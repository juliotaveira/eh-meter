class StringConstants {
	static final String A = "one line const";
	static final String B = "two lines const\n another line";
	static final String C = "two lines const\n"+"another line";
	static final String D = "two lines const\n"
			+"another line";

	String AA = "one line "+"const";
	String BB = "two lines const\n another line";
	String CC = "two lines const\n"+"another line";
	String DD = "two lines const\n"
		+"another line";
}