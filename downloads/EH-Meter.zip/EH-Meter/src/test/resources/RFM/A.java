
class A {
	{
		AA.init();
	}
	
	A() {
		AA.init();
	}
	
	void abc() {
		
	}
	void bcd(int i) {
		abc();
		B b = new B();
		b.efg();
		B.efgh(10);
	}
}

class AA {
	static void init() {}
}

class B {
	void efg() {
		
	}
	static int efgh(int i) {
		System.out.println("");
		return 0;
	}
}

aspect As {
	pointcut bcd() : execution(* A.bcd(..));
	before() : bcd() {
		new D().xyz();
	}
	before() : staticinitialization(B) {}
	before() : execution(A.new(..)) {}

	void method() {
		new C().xyz();
	}
}

interface I {
	void xyz();
}

enum En {
	
}

class C implements I {
	public void xyz() {}
}
class D implements I {
	public void xyz() {}
}

class E {
	void method() {
		I i1 = new C();
		I i2 = new D();
		
		i1.xyz();
		i2.xyz();
	}
}



class Intro {
}

aspect Aspect {
	public void Intro.introMethod() {
		AA.init();
	}
}

class CallToIntro {
	void m(Intro intro) {
		intro.introMethod();
	}
}


aspect DeclareAspect {
	declare parents : DeclareObject extends  DeclareObject2;
	declare soft: CheckedException : call(* DeclareObject2.m2(..));
}

class DeclareObject {}
class DeclareObject2 {
	void m1() throws Exception {
		m2();
	}
	void m2() throws CheckedException {}
}
class CheckedException extends Exception {}