package ann;

import ann.annotations.*;

@TypeAnnotation
public class AnnTest {
	
} 

class AnnTest2 {
	@MethodAnnotation
	void abc() {}
	
	@SuppressWarnings("kljad")
	void acvg() {}
	
}