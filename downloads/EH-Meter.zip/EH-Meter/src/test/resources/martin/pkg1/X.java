package pkg1;

import pkg2.A;

class X {
	A a;
}

abstract class Y {
	A a;
}