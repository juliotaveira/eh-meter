package pkg2;

import java.util.Set;
import java.util.HashSet;

public class A {
	B b = new C();
	D[] tab = new D[10];
	Set<String> set = new HashSet<String>();

	B initA(D par) {
		D.e.abc();
		E.abc();

		return b;
	}
}

abstract class B {
	
}

class C extends B {
	
}

class D {
	static E e;
}

class E {
	static int abc() {
		return 0;
	}
}

class classes {
	class Inner {}
	void classesM() {
		Inner i = new Inner() {
			void adf() {}
		};
	}
}