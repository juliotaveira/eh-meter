package test1.pkg3;

public class Z {
	public void xyz(int i){}
}