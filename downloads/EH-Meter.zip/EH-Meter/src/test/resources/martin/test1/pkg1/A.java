package test1.pkg1;

public abstract class A implements B {
	public void method(C c){
		
	}
}