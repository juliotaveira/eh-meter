package test1.pkg4;

public class NotUsedClass {
	void abc() {
	}
}

class AnotherNotUsedClass {
	int x;
}