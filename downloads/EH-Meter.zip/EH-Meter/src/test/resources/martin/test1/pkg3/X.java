package test1.pkg3;

public class X {
	public static Y y = new Y();

	public void xyz(int i){}
}