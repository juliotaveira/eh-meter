package test1.pkg1;


public interface B {
	void method(C a);
}