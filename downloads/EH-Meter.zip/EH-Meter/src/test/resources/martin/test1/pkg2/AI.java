package test1.pkg2;

import test1.pkg1.A;
import test1.pkg1.B;
import test1.pkg1.C;
import test1.pkg3.Y;
import test1.pkg3.Z;

public class AI extends A {
	public void method(C c){
		
	}
	public B instance() {
		return this;
	}
	
	void method2(Z z){
		test1.pkg3.X x = new test1.pkg3.X();
		Y.xyz(2);
		z.xyz(3);

		x.y.xyz(1);
		test1.pkg3.X.y.xyz(2);
		
		x.y.z.xyz(1);
		test1.pkg3.X.y.z.xyz(2);
	}
}