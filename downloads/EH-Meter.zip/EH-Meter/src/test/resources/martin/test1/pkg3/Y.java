package test1.pkg3;

public class Y {
	public Z z = new Z();
	public static void xyz(int i){}
}