package test1.pkg1;


public interface C {
}