package pkg.pkg2;

public class C {}