package pkg;

import java.util.Comparator;
import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;

public class B {
	static class BInnerStatic {}
	static class BInner {}
	
	void a() {
		Comparator comp = new Comparator() {
			public int compare(Object x, Object y){
				return 0;
			}
			public int compare(String x, String y){
				return 0;
			}
			public boolean equals(Object x){
				B.this.abc();
				return false;
			}
		};

		new DefaultCellEditor((JCheckBox)null).addCellEditorListener(new CellEditorListener(){
			 public void editingCanceled(ChangeEvent e) {
				C c = new C() {
					public void foo(int i){
						System.out.println("Boo: " + i);
						B.this.a2();
					}
				};
			 }
			 public void editingStopped(ChangeEvent e) {
				 B.this.a2();
			 }
		});
	}
	void a2() {
		a();
	}
	int abc() {
		return 0;
	}
}

class BBis {}

aspect Aspect {
	pointcut aCall() : call(void B.a());
	pointcut abcExecution() : execution(* B.abc(..));
	
	before() : abcExecution() {	}
	before() : abcExecution() {	}
	after() : aCall() {	}
	
	declare parents : BBis extends B;
	
	private int BBis.xxx = 3;
	public int BBis.getXXX() {
		return xxx;
	}
}

abstract class C {
	public abstract void foo(int i);
}