public class A {
	void abc() {
		A a = new A() {};
		A b = new A() {};
	}
}