import java.util.*;

class A {
	int a;
	int[] b;
	String s;
	List<String> l;

	A aa;
	A[] atab;
	List<A> alist;
}