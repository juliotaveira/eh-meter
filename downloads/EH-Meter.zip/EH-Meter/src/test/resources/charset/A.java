
class A {
	public void błąd(String komunikat) {
		System.out.println("BŁĄD: " + komunikat);
	}
	private void ęóąśłżźćńĘÓĄŚŁŻŹĆŃ() {		
	}
}

aspect AspectŁÓĆ {
	public void A.drókójBłąd() {
		int ałaMaKota = 0;
		ałaMaKota++;
	}
}

