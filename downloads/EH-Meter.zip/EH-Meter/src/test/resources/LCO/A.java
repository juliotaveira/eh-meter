import org.aspectj.org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;

class A {
	int x;
	static int y;
	int[] t = new int[10];
	String s;
	
	int a;
	static int b;
	
	static {
		b = 3;
	}
	
	{
		a = 1;
		this.a = 2;
	}

	void abc(char c){
		x = 1;
		this.x = 1;

		y = 2;
		this.y = 2;
		A.y = 2;

		t[0] = 2;
		this.t[0] = 2;

		s = new String();
		s.trim();
		s.valueOf(true);
		
		int x = 0;
		x = 2;
		this.x = 2;
		
		c = '0';
	}
	
	void abcd(){
		B b = new B();
		b.a = 1;
		B.b = 10;
		B.m();
		// NPE bug check
		int id = B.m().binding.id;
	}
}

class B {
	int a;
	static int b;
	
	static TypeDeclaration m() { return null; }
}

class C {
	
}

class D {
	int m1(int a){
		return a;
	}
	int m2(int a){
		return a;
	}
	int m3(int a){
		return a;
	}
}

class D1 {
	int m1(int a){
		return a;
	}
	int m2(int a){
		return a;
	}
	int m3(int a){
		return a;
	}
	int z;
	int Z() {
		return z;
	}
}

aspect As {
	int C.x = 1;
	int x;
	int y;
	void C.getX() {
		x = 10;
	}
	void getX() {
		x = 2;
	}
	before() : execution(void getX()) {
		y = 3;
	}
}


class Intro {
	int y;
	void processY() {
		y++;
	}
}

aspect Aspect1 {
	int Intro.var;
	void Intro.introMethod() {
		y++;
		var++;
	}
	void m() {
	}
}
aspect Aspect2 {
	public int Intro.pvar;
	void Intro.introPMethod() {
		y++;
		pvar++;
	}
	void m() {
	}
}

