interface Y {}
interface Z extends Y {}
