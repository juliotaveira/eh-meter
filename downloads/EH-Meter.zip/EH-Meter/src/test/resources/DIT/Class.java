class A {}
class B extends A {}
class C extends B {}


class D extends java.util.ArrayList {}

class E<X> {
	private X var;
	
	E(X init){
		var = init;
	}
}
