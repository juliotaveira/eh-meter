class AA {}
class BB extends AA {}
class CC extends BB {}

class DD extends BB {}

aspect Aspect extends AA {
	declare parents: CC extends DD; 
}
