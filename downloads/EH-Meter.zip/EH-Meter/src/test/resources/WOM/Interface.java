
interface Interface { 
	final static int sx = 0;
	public int getX(); 
	void doIt(); 
} 
