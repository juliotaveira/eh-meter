import java.io.*;
import java.util.List;
 
class Class { 
	int x;
	static int sx;

	{ 
		System.out.println(""); 
	}

	{ x = 0; }
	static { sx = 1; }
	
	public Class() { }
	
	public int getX() { 
		return x;	
	}
	
	public void setX(int x) { 
		this.x = x; 
	}
	 
	public int changeX(int x) { 
		this.x = x;
		return x;
	}
	
	void doIt() { 
		try {
			File f = new File(".");
			f.getCanonicalPath();
		} catch (IOException ioe) {
			System.err.println("!");	
		}	
		setX(10);
		new Point();
	}
} 
