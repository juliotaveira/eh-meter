enum E {
	VAL1, VAL2, VAL3;
	
	boolean isOdd() {
		return this == VAL1 || this == VAL2;
	}
}
