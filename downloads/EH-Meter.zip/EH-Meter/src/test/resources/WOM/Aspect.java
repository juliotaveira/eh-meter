
import java.io.*;
import java.util.List;
 
class Point { 
	int x;
	static int sx;

	{ 
		System.out.println(""); 
	}

	{ x = 0; }
	static { sx = 1; }
	
	public Point() { }
	
	public int getX() { 
		return x;	
	}
	
	public void setX(int x) { 
		this.x = x; 
	}
	 
	public int changeX(int x) { 
		this.x = x;
		return x;
	}
	
	void doIt() { 
		try {
			File f = new File(".");
			f.getCanonicalPath();
		} catch (IOException ioe) {
			System.err.println("!");	
		}	
		setX(10);
		new Point();
	}
} 


aspect Aspect {
	pointcut named(): call(* *.mumble());
	pointcut namedWithOneArg(int i): call(int Point.changeX(int)) && args(i);
	pointcut namedWithArgs(int i, int j): set(int Point.x) && args(i, j);

	after(): named() { }	
	after(int i, int j) returning: namedWithArgs(i, j) { }
	after() throwing: named() { }
	after(): named() { } 
	
	before(): named() { }
	
	int around(int i): namedWithOneArg(i) { return i;}
	
	before(): named() { }	
	before(int i): call(* *.mumble()) && named() && namedWithOneArg(i) { }	
	before(int i): named() && call(* *.mumble()) && namedWithOneArg(i) { }	
	
	before(): call(* *.mumble()) { }
}
  

aspect Aspect2 {
    public int Point.xxx = 0;
    public int Point.check(int i, Point l) { return 1 + i; }
    public Point.new(int i) { this.xxx = i; }

    pointcut illegalNewFigElt(): call(Point.new(..)) && !withincode(* *.doIt(..));

    declare error: illegalNewFigElt(): "Illegal constructor call.";
    declare warning: call(* Point.setX(..)): "Illegal call.";

    declare parents: Point extends java.io.Serializable;
    declare parents: Point+ implements java.util.Observable;
	declare precedence: Aspect, Aspect2, *;
}

