package outer;

import pkg.inner.InnerA;
import pkg.B;

aspect OuterA extends InnerA {}
class OuterB extends B {}