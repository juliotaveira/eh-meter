package pkg;

class A {}
public class B extends A {}

class X extends B {}
aspect Y extends B {}
class Z extends B {}

aspect As {
	declare parents : Y extends Z; 
}