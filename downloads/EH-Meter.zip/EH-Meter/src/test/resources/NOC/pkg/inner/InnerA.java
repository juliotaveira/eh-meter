package pkg.inner;

import pkg.B;

public class InnerA {
	
}

class InnerB extends B {
	
}