package br.upe.dsc.ehmeter.metrics;

import java.util.ArrayList;
import java.util.Stack;

import org.aspectj.org.eclipse.jdt.internal.compiler.ASTVisitor;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.Block;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.MethodDeclaration;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.Statement;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.TryStatement;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
import org.aspectj.org.eclipse.jdt.internal.compiler.lookup.BlockScope;
import org.aspectj.org.eclipse.jdt.internal.compiler.lookup.ClassScope;

import br.upe.dsc.ehmeter.results.Measurement;
import br.upe.dsc.ehmeter.source.MetricsSource;
import br.upe.dsc.ehmeter.source.Project;
import br.upe.dsc.ehmeter.source.Type;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

//TODO Terminar.
public class CDLOC implements MetricsCalculator {
	
	public Measurement[] calculate(MetricsSource source, Project project) {
		CalculatorUtils.assertSourceIsAType(source);
		int result = countCDLOC((Type)source);
		return new Measurement[] {new Measurement(Metrics.CDLOC, result) };
	}

	private int countCDLOC(Type type) {
//		System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
//		System.out.println("Nova contagem:= "+type.getName());
		TypeDeclaration decl = type.getTypeDeclaration();
		int result = 0;
		
		//Soh contabiliza transi��es para c�digo misturado.
		if (!Util.isExceptionHandleAnnotated(type)){
//			System.out.println("countCDLOC...2");
			ConcernDifusionOperationVisitor visitor = new ConcernDifusionOperationVisitor();
			decl.traverse(visitor, decl.scope);
			result = visitor.getValue();
		}
//		System.out.println("**####Classe:= "+type.getName());
//		System.out.println("!!####Valor:= "+result);
		return result;
	}
	
	private static class ConcernDifusionOperationVisitor extends ASTVisitor {
		
		private int value = 0;
		private int transitionsInMethod = 0;
		private boolean currentStatementIsTry = false;
		private ArrayList<CatchAreaValues> cacthAreaList = new ArrayList<CatchAreaValues>();
		private ArrayList<Block> recursivedBlocks = new ArrayList<Block>();

		public boolean visit(MethodDeclaration methodDeclaration, ClassScope scope) {
//			System.out.println("MethodDeclaration...1");
			this.transitionsInMethod = 0;
			this.currentStatementIsTry = false;
			try{
//				System.out.println("MethodDeclaration...2");
				this.transitionsInMethod += countTrasitions(methodDeclaration.statements);
			}catch (Exception e){
				e.printStackTrace();
			}
			
			return super.visit(methodDeclaration, scope);
		};
		
		public boolean visit(Block block, BlockScope scope) {
//			System.out.println(">>Block....1");
//			System.out.println("------------------");
//			System.out.println("\t inCatchArea="+inCacthArea(block.sourceStart, block.sourceEnd));
//			System.out.println("\t recursivedBlocks.contains="+this.recursivedBlocks.contains(block));
//			System.out.println("------------------");
			if (!inCacthArea(block.sourceStart, block.sourceEnd) && !this.recursivedBlocks.contains(block)){
//				System.out.println(">>Block....2");
				this.transitionsInMethod += countTrasitions(block.statements);
			}
			
			return super.visit(block, scope);
		}
		
		public boolean visit(TryStatement tryStatement, BlockScope scope) {
			Block [] blocksCatch = tryStatement.catchBlocks;
			
			CatchAreaValues catchArea = new CatchAreaValues();
			
			if (blocksCatch != null) {
				for (int i = 0; i < blocksCatch.length; i++) {
					if (blocksCatch[i].sourceStart < catchArea.init){
						catchArea.init = blocksCatch[i].sourceStart;
					}
					if (blocksCatch[i].sourceEnd > catchArea.end){
						catchArea.end = blocksCatch[i].sourceEnd;
					}
				}
			}
			if (tryStatement.finallyBlock != null) {
				if (tryStatement.finallyBlock.sourceStart < catchArea.init){
					catchArea.init = tryStatement.finallyBlock.sourceStart;
				}
				if (tryStatement.finallyBlock.sourceEnd > catchArea.end){
					catchArea.end = tryStatement.finallyBlock.sourceEnd;
				}
			}
			
			this.cacthAreaList.add(catchArea);
			return super.visit(tryStatement, scope);
		}

		private int countTrasitions(Statement[] statement) {
			int result = 0;
//			System.out.println("countTrasitions...1");
			if (statement == null){
				return result;
			}
//			System.out.println("countTrasitions...2");
			for (int i = 0; i < statement.length; i++) {
//				System.out.println("countTrasitions...3");
//				System.out.println("\t currentStatement += "+statement[i].getClass());
//				System.out.println("\t currentStatementIsTry += "+currentStatementIsTry);
				if (statement[i] instanceof TryStatement){
//					System.out.println("countTrasitions...4");
					if (!currentStatementIsTry){
//						System.out.println("countTrasitions...5!!!");
						result++;
//						System.out.println(statement[i]);
					}
					this.currentStatementIsTry = true;
//					System.out.println("countTrasitions...5.1");
					//Recurs�o para dentro do bloco try
					Block internalTryBlock = ((TryStatement) statement[i]).tryBlock;
					if (internalTryBlock.statements != null && internalTryBlock.statements.length > 0){
//						System.out.println("countTrasitions...5.2");
						if (internalTryBlock.statements[0] instanceof TryStatement){
//							System.out.println("countTrasitions...5.3");
							this.recursivedBlocks.add(internalTryBlock);
							result += this.countTrasitions(internalTryBlock.statements);
						}else{
//							System.out.println("countTrasitions...5.4!!");
							result++;
							int lastStatementIndex = internalTryBlock.statements.length - 1;
							if (!(internalTryBlock.statements[lastStatementIndex] instanceof TryStatement)){
//								System.out.println("countTrasitions...5.5!!!");
								result++;
							}
						}
						this.currentStatementIsTry = true;
					}
					
				} else {
//					System.out.println("countTrasitions...6");
					if (currentStatementIsTry){
//						System.out.println("countTrasitions...7!!!");
						result++;
//						System.out.println(statement[i]);
					}
					this.currentStatementIsTry = false;
				}
			}
			return result;
		}
		
		private boolean inCacthArea(int sourceStart, int sourceEnd) {
			boolean result = false;
			for (int j = 0; j < this.cacthAreaList.size(); j++) {
				CatchAreaValues catchArea = this.cacthAreaList.get(j);
				if (sourceStart >= catchArea.init && sourceEnd <= catchArea.end){
					result = true;
				}
			}
			return result;
		}

//		public void endVisit(TryStatement tryStatement, BlockScope scope) {
//			this.currentStatementIsTry = true;
//			this.cacthAreaStack.remove(tryStatement);
//		}
		
//		public void endVisit(Block block, BlockScope scope) {
//			if (!inCacthArea(block.sourceStart, block.sourceEnd)){
//				if (!this.currentStatementIsTry){
//					this.transitionsInMethod++;
//				}
//			}
//			super.endVisit(block, scope);
//		}
		
		public void endVisit(MethodDeclaration methodDeclaration, ClassScope scope) {
			if (this.currentStatementIsTry){
				this.transitionsInMethod++;
			}
			this.value += this.transitionsInMethod;
			super.endVisit(methodDeclaration, scope);
		}
//		
		public int getValue() {
			return this.value;
		}
		
		private class CatchAreaValues {
			int init = Integer.MAX_VALUE;
			int end = 0;
		}
	}
}
