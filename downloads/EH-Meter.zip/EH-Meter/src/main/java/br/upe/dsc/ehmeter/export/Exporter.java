package br.upe.dsc.ehmeter.export;

import br.upe.dsc.ehmeter.results.ProjectMeasurements;
/*
 * The code is original from AOPMetrics Version.
 */
/**
 * @author misto
 */
public interface Exporter {
	public abstract void export(ProjectMeasurements project, String file) throws ExporterException;
	public abstract String export(ProjectMeasurements project) throws ExporterException;
}