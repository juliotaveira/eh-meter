package br.upe.dsc.ehmeter.ajdt;
/*
 * The code is original from AOPMetrics Version.
 */
public class AjdtBuilderException extends Exception {
	private static final long serialVersionUID = 3618138931384629556L;

	public AjdtBuilderException(String arg0) {
		super(arg0);

	}
	public AjdtBuilderException(String arg0, Throwable arg1) {
		super(arg0, arg1);

	}
}
