package br.upe.dsc.ehmeter.metrics;

import org.aspectj.org.eclipse.jdt.internal.compiler.ASTVisitor;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.TryStatement;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
import org.aspectj.org.eclipse.jdt.internal.compiler.lookup.BlockScope;

import br.upe.dsc.ehmeter.results.Measurement;
import br.upe.dsc.ehmeter.source.MetricsSource;
import br.upe.dsc.ehmeter.source.Project;
import br.upe.dsc.ehmeter.source.Type;

/**
 * CDC metric class.
 * */
public class CDC implements MetricsCalculator {

	public Measurement[] calculate(MetricsSource source, Project project) {
		CalculatorUtils.assertSourceIsAType(source);
		int result = countCDC((Type)source);
		return new Measurement[] {new Measurement(Metrics.CDC, result) };
	}

	private int countCDC(Type type) {
		TypeDeclaration decl = type.getTypeDeclaration();
		int result = 0;
		
		if (Util.isExceptionHandleAnnotated(type)){
			result = 1;
		}else{
			CDCVisitor visitor = new CDCVisitor();
			decl.traverse(visitor, decl.scope);
			result = visitor.getValue();
		}
		
		return result;
	}
	
	private static class CDCVisitor extends ASTVisitor {
		private int numerTry = 0;

		public boolean visit(TryStatement tryStatement, BlockScope scope) {
			this.numerTry++;
			return super.visit(tryStatement,scope);
		}
		
		public int getValue() {
			return (this.numerTry > 0) ? 1 : 0;
		}
	}
}
