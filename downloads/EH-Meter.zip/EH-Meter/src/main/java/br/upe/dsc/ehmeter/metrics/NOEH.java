package br.upe.dsc.ehmeter.metrics;

import org.aspectj.org.eclipse.jdt.internal.compiler.ASTVisitor;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.Block;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.MessageSend;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.MethodDeclaration;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.Statement;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.TryStatement;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
import org.aspectj.org.eclipse.jdt.internal.compiler.lookup.BlockScope;
import org.aspectj.org.eclipse.jdt.internal.compiler.lookup.ClassScope;
import org.aspectj.org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;

import br.upe.dsc.ehmeter.results.Measurement;
import br.upe.dsc.ehmeter.source.MetricsSource;
import br.upe.dsc.ehmeter.source.Project;
import br.upe.dsc.ehmeter.source.Type;

/**
 * Number of Exception Handler metric class.
 * */
public class NOEH implements MetricsCalculator {
	private Project project = null;
	
	public Measurement[] calculate(MetricsSource source, Project project) {
		this.project = project;
		CalculatorUtils.assertSourceIsAType(source);
		int result = countOperationsInModule((Type)source);
		return new Measurement[] {new Measurement(Metrics.NOEH, result) };
	}

	private int countOperationsInModule(Type type) {
		TypeDeclaration decl = type.getTypeDeclaration();
		int result = 0;
		
		if (Util.isExceptionHandleAnnotated(type) && Util.isClass(type)){
			CountMetodosVisitor visitor = new CountMetodosVisitor();
			decl.traverse(visitor, decl.scope);
			result = visitor.getValue();
		}else{
			CDOVisitor visitor = new CDOVisitor(project);
			decl.traverse(visitor, decl.scope);
			result = visitor.getValue();
		}
		return result;
	}
	
	//Conta os metodos que possuem try/catch
	private static class CDOVisitor extends ASTVisitor {
		private int value = 0;
		private Project project;
		
		public CDOVisitor(Project p){
			this.project = p;
		}
		
		public boolean visit(TryStatement tryStatement, BlockScope scope) {
			Block [] blocks = tryStatement.catchBlocks;
			if (blocks != null){
				for (int i = 0; i < blocks.length; i++) {
					if (!hasCallExceptionHandleMethodOrEmpty(blocks[i])){
						value ++;
					}
				}
			}
			
			if (tryStatement.finallyBlock != null && !hasCallExceptionHandleMethodOrEmpty(tryStatement.finallyBlock)){
				value ++;
			}
			
			return super.visit(tryStatement,scope);
		}

		private boolean hasCallExceptionHandleMethodOrEmpty(Block block) {
			boolean result = false;
			//XXX Verificar se for vazio tamb�m n�o conta
			if (block.statements == null || block.statements == null){
				result = true;
			}else{
				//Verifica se o bloco chama um m�todo que trata exce�oes
				//Somente pode chamar se o n de statements nao for nulo e se for 1 o tamalho.
				if (block.statements != null && block.statements.length == 1){
					Statement stm = block.statements[0];
					if (stm instanceof MessageSend){
						MessageSend mSend = (MessageSend) stm;
						ReferenceBinding rb = mSend.binding.declaringClass;
						Type typeTarget = Util.getTypeFromProject(rb.compoundName, this.project);
						if (typeTarget != null && Util.isExceptionHandleAnnotated(typeTarget)){
							result = true;
						}
					}
				}
			}
			return result;
		}
		
		public int getValue() {
			return this.value;
		}
	}
	
	//Conta todos os metodos que forem referentes a tratamento de exce��o.
	private static class CountMetodosVisitor extends ASTVisitor{
		
		private int value;

		public boolean visit(MethodDeclaration methodDeclaration, ClassScope scope) {
//			if (Util.isMethodExceptionHandler(methodDeclaration)) {
				value++;
//			}
			return super.visit(methodDeclaration, scope);
		};
		
		public int getValue() {
			return this.value;
		}
	}
}
