package br.upe.dsc.ehmeter;


import br.upe.dsc.ehmeter.metrics.Metrics;
import br.upe.dsc.ehmeter.metrics.MetricsCalculator;
import br.upe.dsc.ehmeter.metrics.MetricsCalculatorGeneral;
import br.upe.dsc.ehmeter.results.PackageMeasurements;
import br.upe.dsc.ehmeter.results.ProjectMeasurements;
import br.upe.dsc.ehmeter.results.TypeMeasurements;
import br.upe.dsc.ehmeter.source.MetricsSource;
import br.upe.dsc.ehmeter.source.Package;
import br.upe.dsc.ehmeter.source.Project;
import br.upe.dsc.ehmeter.source.Type;

/**
 * @author misto
 */
public class Engine {
	
	public ProjectMeasurements calculateMetrics(Project project) {
		ProjectMeasurements projectMeasures = new ProjectMeasurements(project.getName());
		
		for( Package pkg : project.getPackages() ){
			PackageMeasurements packageMeasures = calculateMetricsForPackage(pkg, project);
			projectMeasures.addPackage(packageMeasures);
		}
		
		projectMeasures.addPackage(calculateGeneralMetrics());
		
		return projectMeasures;
	}

	private PackageMeasurements calculateMetricsForPackage(Package pkg, Project project) {
		PackageMeasurements packageMeasures = new PackageMeasurements(pkg.getName());

		for( Type type : pkg.getTypes()){
			if (type.getKind() != MetricsSource.Kind.ANNOTATION){
				TypeMeasurements typeMeasures = calculateMetricsForType(type, project);
				packageMeasures.addType(typeMeasures);
			}
		}


		return packageMeasures;
	}

	private TypeMeasurements calculateMetricsForType(Type type, Project project) {
		TypeMeasurements typeMeasures = new TypeMeasurements(type.getName());
		typeMeasures.setKind(type.getKind().name().toLowerCase());
		
		for(MetricsCalculator calc : Metrics.typeMetricsCalculators) {
			typeMeasures.addMeasurements(calc.calculate(type, project));
		}
		
		//Envia o valor para cada tipo existente.
		for(MetricsCalculatorGeneral calc : Metrics.typeMetricsGeneral) {
			calc.calculate(type, project);
		}
		
		return typeMeasures;
	}
	
	private PackageMeasurements calculateGeneralMetrics(){
		PackageMeasurements packageMeasures = new PackageMeasurements("General in Project");
		
		TypeMeasurements typeMeasures = new TypeMeasurements("General in Project");
		typeMeasures.setKind("General in Project");
		
		for(MetricsCalculatorGeneral calc : Metrics.typeMetricsGeneral) {
			typeMeasures.addMeasurement(calc.generateResult());
		}
		
		packageMeasures.addType(typeMeasures);
		
		return packageMeasures;
	}
}
