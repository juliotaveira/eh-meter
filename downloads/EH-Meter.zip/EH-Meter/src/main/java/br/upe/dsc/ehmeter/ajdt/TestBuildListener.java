/* *******************************************************************
 * Copyright (c) 2002 Palo Alto Research Center, Incorporated (PARC).
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Xerox/PARC     initial implementation 
 * ******************************************************************/


package br.upe.dsc.ehmeter.ajdt;

import org.aspectj.ajde.BuildListener;

/*
 * The code is original from AOPMetrics Version.
 */
public class TestBuildListener implements BuildListener {
	public boolean buildFinished = false;
	public boolean buildSucceeded = false;

	public void reset() { 
		buildFinished = false;
	}

	public void compileStarted(String buildConfigFile) {}
    public void compileFinished(String buildConfigFile, int buildTime, boolean succeeded, boolean warnings) {
        buildSucceeded = succeeded;
		buildFinished = true;
    } 
    public void compileAborted(String buildConfigFile, String message) {}
    public boolean getBuildFinished() { return buildFinished; }
    public boolean getBuildSucceeded() { return buildSucceeded; }
}


