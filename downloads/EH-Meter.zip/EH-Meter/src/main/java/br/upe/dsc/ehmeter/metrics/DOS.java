package br.upe.dsc.ehmeter.metrics;

import java.util.ArrayList;


import br.upe.dsc.ehmeter.results.Measurement;
import br.upe.dsc.ehmeter.source.MetricsSource;
import br.upe.dsc.ehmeter.source.Project;
import br.upe.dsc.ehmeter.source.Type;

public class DOS implements MetricsCalculatorGeneral {
	private int totalLOC = 0;
	
	private ArrayList<Values> values = new ArrayList<Values>();
	
	public void calculate(MetricsSource source, Project project)
			throws InvalidMetricsSourceException {
		
		Type type = (Type) source;
		
		if (Util.isAnnotation(type)){
			return;
		}
		
		LOCEH locConcernT = new LOCEH();
		int valueLocConcernT = locConcernT.countLOCExceptionHandle(type);
		
		Values val = new Values();
		val.type = type;
		val.SLOCComponent = valueLocConcernT;
		
		this.values.add(val);
		
		totalLOC += valueLocConcernT;
		
	}

	public Measurement generateResult() {
		Measurement result = null;
		double resultTmp = 0;
		double sum = 0;
		for(Values val: this.values) {
			val.totalSLOC = totalLOC;
			val.t = this.values.size();
			sum += val.calculate();
		}
		
		double dividendo = values.size()*sum;
		double divisor = values.size() - 1;
		resultTmp = 1 - (dividendo/divisor);
		result = new Measurement(Metrics.DOS, resultTmp);
		return result;
	}
	
	private class Values {
		Type type;
		int SLOCComponent;
		int totalSLOC; 
		int t;
		
		public double calculate(){
			double result = 0;
			double conc = (double) this.SLOCComponent / this.totalSLOC;
			double tmp = conc - (1.00/(double)t);
			result = Math.pow(tmp,2);
			return result;
		}
	}
}
