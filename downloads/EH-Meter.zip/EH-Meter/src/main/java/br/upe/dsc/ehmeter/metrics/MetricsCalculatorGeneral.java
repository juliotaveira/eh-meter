package br.upe.dsc.ehmeter.metrics;


import br.upe.dsc.ehmeter.results.Measurement;
import br.upe.dsc.ehmeter.source.MetricsSource;
import br.upe.dsc.ehmeter.source.Project;

public interface MetricsCalculatorGeneral {
	public Measurement  generateResult();
	public void calculate(MetricsSource source, Project project) throws InvalidMetricsSourceException; 
}
