/*
 * AopMetricsRunnerException.java, created on 2006-04-09
 * 
 * Copyright 2004 Wroclaw University of Technology. All rights reserved.
 */
package br.upe.dsc.ehmeter;

/*
 * EHMeterTask::
 * Renamed class from AOPMetrics Project.
 * The code is original from AOPMetrics Version.
 */
/**
 *
 * @author <a href="mailto:misto@e-informatyka.pl">Michal Stochmialek</a>
 * @version CVS $Revision: 1.1 $
 */
public class EHMeterRunnerException extends Exception {
	public EHMeterRunnerException(String msg) {
		super(msg);
	}
}
