package br.upe.dsc.ehmeter.metrics;


import br.upe.dsc.ehmeter.results.Measurement;
import br.upe.dsc.ehmeter.source.MetricsSource;
import br.upe.dsc.ehmeter.source.Project;
import br.upe.dsc.ehmeter.source.Type;
public class DOF implements MetricsCalculator {
	private static final double NUMBER_OF_CONCERNS = 2;
	
	static{
		if (NUMBER_OF_CONCERNS <= 1){
			new IllegalStateException("O n�mero de concerns deve ser > 1.");
		}
	}
	
	public Measurement[] calculate(MetricsSource source, Project project)
			throws InvalidMetricsSourceException {
		
		Type type = (Type) source;
		
		if (Util.isAnnotation(type)){
			return null;
		}
		
		LOCEH locConcernT = new LOCEH();
		int valueLocConcernT = locConcernT.countLOCExceptionHandle(type);
		
		LinesOfClassCode linesOfClassCode = new LinesOfClassCode();
		int totalLOC = linesOfClassCode.countLinesOfSource(type);
		
		double dedi_exceptionHandler = ((double)valueLocConcernT) / ((double)totalLOC);
		dedi_exceptionHandler = dedi_exceptionHandler - (1.0/NUMBER_OF_CONCERNS);
		dedi_exceptionHandler = Math.pow(dedi_exceptionHandler,2);
		
		double dedi_generalBehaviour = ((double)totalLOC - valueLocConcernT) / ((double)totalLOC);
		dedi_generalBehaviour = dedi_generalBehaviour - (1.0/NUMBER_OF_CONCERNS);
		dedi_generalBehaviour = Math.pow(dedi_generalBehaviour,2);
		
		double dof = (NUMBER_OF_CONCERNS * (dedi_exceptionHandler + dedi_generalBehaviour)) / 
		(( NUMBER_OF_CONCERNS)-((double) 1));
		
		return new Measurement[] {new Measurement(Metrics.DOF, dof)};
		
	}

	
}
