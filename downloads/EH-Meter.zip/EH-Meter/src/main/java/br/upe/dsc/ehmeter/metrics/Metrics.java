
package br.upe.dsc.ehmeter.metrics;

public class Metrics {
	public static final String LOCC = "LOCC";

	public static final String NOT = "NOT";
	public static final String NOF = "NOF";
	public static final String NOC = "NOC";
	public static final String NOEH= "NOEH";
	public static final String LOCEH = "LOCEH";
	public static final String CDO = "CDO";
	public static final String CDC = "CDC";
	public static final String CDLOC = "CDLOC";
	public static final String DOS = "DOS";
	public static final String DOF = "DOF";

	public static final MetricsCalculator[] typeMetricsCalculators = {
		new LinesOfClassCode(),
		new NOT(),
		new NOC(),
		new NOF(),
		new LOCEH(),
		new CDO(),
		new CDLOC(),
		new CDC(),
		new NOEH(),
		new DOF()
	};
	
	public static final MetricsCalculatorGeneral[] typeMetricsGeneral = {
		new DOS()
	}; 
	
	private Metrics() {}
}
