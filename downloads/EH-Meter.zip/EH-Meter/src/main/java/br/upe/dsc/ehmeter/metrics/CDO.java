package br.upe.dsc.ehmeter.metrics;

import org.aspectj.org.eclipse.jdt.internal.compiler.ASTVisitor;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.Block;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.MethodDeclaration;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.TryStatement;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
import org.aspectj.org.eclipse.jdt.internal.compiler.lookup.BlockScope;
import org.aspectj.org.eclipse.jdt.internal.compiler.lookup.ClassScope;

import br.upe.dsc.ehmeter.results.Measurement;
import br.upe.dsc.ehmeter.source.MetricsSource;
import br.upe.dsc.ehmeter.source.Project;
import br.upe.dsc.ehmeter.source.Type;

public class CDO implements MetricsCalculator {
	public Measurement[] calculate(MetricsSource source, Project project) {
		CalculatorUtils.assertSourceIsAType(source);
		int result = countOperationsInModule((Type)source);
		return new Measurement[] {new Measurement(Metrics.CDO, result) };
	}

	private int countOperationsInModule(Type type) {
		TypeDeclaration decl = type.getTypeDeclaration();
		int result = 0;
		
		if (Util.isExceptionHandleAnnotated(type) && Util.isClass(type)){
			CountMetodosVisitor visitor = new CountMetodosVisitor();
			decl.traverse(visitor, decl.scope);
			result = visitor.getValue();
		}else{
			CDOVisitor visitor = new CDOVisitor();
			decl.traverse(visitor, decl.scope);
			result = visitor.getValue();
		}
		return result;
	}
	
	//Conta os metodos que possuem try/catch
	private static class CDOVisitor extends ASTVisitor {
		private int value = 0;
		private int numerTry;
		
		public boolean visit(MethodDeclaration methodDeclaration,
				ClassScope scope) {
			numerTry = 0;
			return super.visit(methodDeclaration, scope);
		}
		
		public boolean visit(TryStatement tryStatement, BlockScope scope) {
			Block [] blocks = tryStatement.catchBlocks;
			if (blocks != null ){
				for (int i = 0; i < blocks.length; i++) {
						this.numerTry++;
				}
			}
			if (tryStatement.finallyBlock != null){
				this.numerTry++;
			}
			return super.visit(tryStatement,scope);
		}

		
		public void endVisit(MethodDeclaration methodDeclaration, ClassScope scope) {
			if (numerTry>0){
				this.value++;
			}
		}
		
		public int getValue() {
			return this.value;
		}
	}
	
	//Conta todos os metodos que forem referentes a tratamento de exce��o.
	private static class CountMetodosVisitor extends ASTVisitor{
		
		private int value;

		public boolean visit(MethodDeclaration methodDeclaration, ClassScope scope) {
			value++;
			return super.visit(methodDeclaration, scope);
		};
		
		public int getValue() {
			return this.value;
		}
	}
}
