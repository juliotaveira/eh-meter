package br.upe.dsc.ehmeter.metrics;

import org.aspectj.org.eclipse.jdt.internal.compiler.ASTVisitor;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.Block;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.TryStatement;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
import org.aspectj.org.eclipse.jdt.internal.compiler.lookup.BlockScope;

import br.upe.dsc.ehmeter.results.Measurement;
import br.upe.dsc.ehmeter.source.MetricsSource;
import br.upe.dsc.ehmeter.source.Project;
import br.upe.dsc.ehmeter.source.Type;


public class LOCEH implements MetricsCalculator {
	
	public Measurement[] calculate(MetricsSource source, Project project) {
		CalculatorUtils.assertSourceIsAType(source);
		int result = countLOCExceptionHandle((Type)source);
		return new Measurement[] {new Measurement(Metrics.LOCEH, result) };
	}

	int countLOCExceptionHandle(Type type) {
		int result = 0;
		TypeDeclaration decl = type.getTypeDeclaration();
		if (Util.isExceptionHandleAnnotated(type)){
			LinesOfClassCode locc = new LinesOfClassCode();
			result = locc.countLinesOfSource(type);
		} else{
			LOCExceptionHandleVisitor visitor = new LOCExceptionHandleVisitor();
			decl.traverse(visitor, decl.scope);
			result = visitor.getValue();
		}
		return result;
	}
	
	static int countNewlines(String perfectSource) {
		char[] chars = perfectSource.toCharArray();
		int result = 0;
		for(char c : chars){
			if (c == '\n') result ++;
		}
		// last line is without '\n'
		result++;

		return result;
	}

	private static class LOCExceptionHandleVisitor extends ASTVisitor {
		private int value = 0;
		private int tryDepth = 0;
		//Verifica onde acaba o primeiro try para verificar se o catch � do c�digo
		private int firstTrySourceEnd = Integer.MAX_VALUE;

		public boolean visit(TryStatement tryStatement, BlockScope scope) {
			Block blockTry = tryStatement.tryBlock;
			if (tryDepth == 0){
				firstTrySourceEnd = blockTry.sourceEnd;
				value+= countLinesTryStatement(tryStatement);
			} else if (blockTry.sourceStart < firstTrySourceEnd) {
				//O c�digo do try est� dentro do primeiro try
				value+= countLinesTryStatement(tryStatement);
			}
			this.tryDepth++;
			return super.visit(tryStatement,scope);
		}
		
		private int countLinesTryStatement(TryStatement tryStatement){
			int result = 1; //conta sempre o try
			Block [] blocks = tryStatement.catchBlocks;
			if (blocks != null){
				for (int i = 0; i < blocks.length; i++) {
					result += countNewlines(blocks[i].toString());
				}
			}
			
			Block finallyBlock = tryStatement.finallyBlock;
			if (finallyBlock != null){
				result += countNewlines(finallyBlock.toString());
			}
			return result;
		}

		public void endVisit(TryStatement tryStatement, BlockScope scope) {
			this.tryDepth--;
			if (this.tryDepth == 0){
				firstTrySourceEnd = Integer.MAX_VALUE;
			}
			super.endVisit(tryStatement, scope);
		}

		public int getValue() {
			return this.value;
		}
	}

	
}
