package br.upe.dsc.ehmeter.metrics;


import br.upe.dsc.ehmeter.results.Measurement;
import br.upe.dsc.ehmeter.source.MetricsSource;
import br.upe.dsc.ehmeter.source.Project;


public interface MetricsCalculator {
	Measurement[] calculate(MetricsSource source, Project project) throws InvalidMetricsSourceException;  
}
