package br.upe.dsc.ehmeter.metrics;

import org.aspectj.org.eclipse.jdt.internal.compiler.ASTVisitor;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.Block;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.TryStatement;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
import org.aspectj.org.eclipse.jdt.internal.compiler.lookup.BlockScope;

import br.upe.dsc.ehmeter.results.Measurement;
import br.upe.dsc.ehmeter.source.MetricsSource;
import br.upe.dsc.ehmeter.source.Project;
import br.upe.dsc.ehmeter.source.Type;

/**
 * Number of Catch metric class.
 * */
public class NOC implements MetricsCalculator {

	public Measurement[] calculate(MetricsSource source, Project project) {
		CalculatorUtils.assertSourceIsAType(source);
		int result = countNumberOfCatch((Type)source);
		return new Measurement[] {new Measurement(Metrics.NOC, result) };
	}

	int countNumberOfCatch(Type type) {
		TypeDeclaration decl = type.getTypeDeclaration();
		
		NOTryVisitor visitor = new NOTryVisitor();
		
		decl.traverse(visitor, decl.scope);
		return visitor.getNOTryValue();
	}
	
	//Number of Try Visitor
	private static class NOTryVisitor extends ASTVisitor {
		private int value;

		public boolean visit(TryStatement tryStatement, BlockScope scope) {
			Block [] blocks = tryStatement.catchBlocks;
			if (blocks != null){
				this.value += blocks.length;
			}
			return super.visit(tryStatement,scope);
		};
		
//		private int countTry(Statement [] statements){
//			int result = 0;
//			if (statements != null){
//				for (int i = 0; i < statements.length; i++) {
//					Statement statement = statements[i];
//					Class statementClass = statement.getClass();
//					if (statementClass == TryStatement.class){
//						result++;
//						TryStatement t = (TryStatement) statement;
//						Block b = t.tryBlock;
//					}
//					
//				}
//			}
//			return result;
//		}

		public int getNOTryValue() {
			return this.value;
		}
	}
}
