package br.upe.dsc.ehmeter.export;
/*
 * The code is original from AOPMetrics Version.
 */
/**
 * @author misto
 */
public class ExporterException extends Exception {
	public ExporterException(String msg) {
		super(msg);
	}
	public ExporterException(String msg, Throwable cause) {
		super(msg, cause);
	}
}
