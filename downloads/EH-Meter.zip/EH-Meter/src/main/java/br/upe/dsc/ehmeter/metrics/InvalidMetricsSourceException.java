package br.upe.dsc.ehmeter.metrics;

public class InvalidMetricsSourceException extends RuntimeException {
	public InvalidMetricsSourceException(String msg) {
		super(msg);
	}
}
