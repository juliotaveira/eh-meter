package br.upe.dsc.ehmeter;

import java.io.File;
import java.nio.charset.Charset;


import br.upe.dsc.ehmeter.ajdt.AjdtBuilder;
import br.upe.dsc.ehmeter.ajdt.AjdtBuilderException;
import br.upe.dsc.ehmeter.export.Exporter;
import br.upe.dsc.ehmeter.export.ExporterException;
import br.upe.dsc.ehmeter.export.ExporterFactory;
import br.upe.dsc.ehmeter.results.ProjectMeasurements;
import br.upe.dsc.ehmeter.source.Project;



/*
 * EHMeterRunner::
 * Renamed class from AOPMetrics Project.
 * The code is original from AOPMetrics Version.
 */
public class EHMeterRunner {
	private EHMeterOptions options;

	public void execute(EHMeterOptions options) throws EHMeterRunnerException {
		this.options = options;
		verifyOptions();
		
		Logger.msg("Building and measuring " + options.getProjectName() + " project.");
		long start = System.currentTimeMillis();
		
		Project project = buildProject();
		ProjectMeasurements measures = measureProject(project);
		exportMeasurements(measures);
		
		long end = System.currentTimeMillis();
		Logger.info("Build and measurement time: " + (end - start)/1000.0 + "s");
	}

	private Project buildProject() throws EHMeterRunnerException{
		AjdtBuilder builder = new AjdtBuilder();

		builder.setClasspath(options.getClasspath());
		builder.setRootClasspath(options.getRootClasspath());
		builder.setProjectName(options.getProjectName());
		builder.setWorkdir(options.getWorkdir().getAbsolutePath());
		builder.setConfigfile(options.getConfigfile().getAbsolutePath());
		builder.setSourceLevel(options.getSourcelevel());
		builder.setCharset(options.getCharset());

		try {
			return builder.build();
		} catch(AjdtBuilderException e){
			throw new EHMeterRunnerException(e.getMessage());
		}
	}

	private ProjectMeasurements measureProject(Project project) {
		Engine engine = new Engine();
		return engine.calculateMetrics(project);
	}
	private void exportMeasurements(ProjectMeasurements measures) throws EHMeterRunnerException{
		Exporter exporter = ExporterFactory.createExporter(options.getExport());
		try {
			if (options.getResultsfile() == null)
				System.out.println(exporter.export(measures));
			else {
				createResultDir();
				exporter.export(measures, options.getResultsfile().getAbsolutePath());
			}
		} catch (ExporterException e) {
			throw new EHMeterRunnerException(e.getMessage());
		}
	}
	
	private void createResultDir() {
		if (options.getResultsfile() != null) {
			File resultsDir = options.getResultsfile().getParentFile();
			if (resultsDir != null && !resultsDir.exists())
				resultsDir.mkdirs();
		}
	}

	private void verifyOptions() throws EHMeterRunnerException {
		if (options.getWorkdir() == null)
			throw new EHMeterRunnerException("Workdir must be specified.");
		if (options.getWorkdir() != null && !options.getWorkdir().isDirectory()) {
			if (options.getWorkdir().exists())
				throw new EHMeterRunnerException("Workdir is not a regular directory.");
			else
				options.getWorkdir().mkdirs();
		}
		
		if (options.getVerbose() != null)
			Logger.setMode(options.getVerbose());

		if (options.getSourcelevel() != null 
				&& !(options.getSourcelevel().equals("1.5") || options.getSourcelevel().equals("1.4") || options.getSourcelevel().equals("1.3")) )
			throw new EHMeterRunnerException("Sourcelevel can be one of 1.3, 1.4 or 1.5 values.");

		if (options.getCharset() != null && !Charset.isSupported(this.options.getCharset()))
			throw new EHMeterRunnerException("Charset '"+this.options.getCharset()+"' isn't supported.");

		if (options.getClasspath() == null)
			options.setClasspath("");

		if (ExporterFactory.createExporter(this.options.getExport()) == null)
			throw new EHMeterRunnerException("Unknown export type.");

		if (options.getConfigfile() == null){
			throw new EHMeterRunnerException("Configfile isn't specified.");
		}
		if (options.getConfigfile() != null && !options.getConfigfile().isFile() ){
			throw new EHMeterRunnerException("Configfile is not a regular file.");
		}

	}

}
