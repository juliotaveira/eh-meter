package br.upe.dsc.ehmeter.metrics;

import org.aspectj.org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;

import br.upe.dsc.ehmeter.source.MetricsSource;
import br.upe.dsc.ehmeter.source.Package;
import br.upe.dsc.ehmeter.source.Project;
import br.upe.dsc.ehmeter.source.Type;

public class Util {

	public static boolean isExceptionHandleAnnotated(Type type){
		TypeDeclaration typeDec = type.getTypeDeclaration();
		
		boolean result = false;
		for (int i = 0; typeDec.annotations != null && i < typeDec.annotations.length; i++) {
			if (typeDec.annotations[i].toString().equals("@ExceptionHandler")){
				result = true;
				break;
			}
		}
		if(!result){
			if (type.getName().contains("ExceptionHandler")){
				result = true;
			}
		}
		return result;
	}
	
	public static boolean isAspect(Type type){
		boolean result = false;
		if (type.getKind() == MetricsSource.Kind.ASPECT){
			result = true;
		}
		return result;
	}
	
	public static boolean isClass(Type type){
		boolean result = false;
		if (type.getKind() == MetricsSource.Kind.CLASS){
			result = true;
		}
		return result;
	}
	
	public static boolean isAnnotation(Type type){
		boolean result = false;
		if (type.getKind() == MetricsSource.Kind.ANNOTATION){
			result = true;
		}
		return result;
	}

	
	public static Type getTypeFromProject(char[][] copoundName, Project project){
		Type result = null;
//		Iterator<Package> ps = project.getPackages().iterator();
//		System.out.println("------------------------");
//		while(ps.hasNext()){
//			System.out.println("Package:= " + ps.next());
//		}
//		System.out.println("------------------------");
		
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < copoundName.length-1; i++) {
			if (i!=0){
				sb.append('.');
			}
			sb.append(copoundName[i]);
		}
		Package p = project.getPackage(sb.toString());
		if (p != null){
			result = p.getType(new String(copoundName[copoundName.length-1]));
		}
		return result;
	}
}
