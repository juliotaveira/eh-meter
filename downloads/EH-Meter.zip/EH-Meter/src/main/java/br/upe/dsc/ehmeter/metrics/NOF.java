package br.upe.dsc.ehmeter.metrics;

import org.aspectj.org.eclipse.jdt.internal.compiler.ASTVisitor;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.Block;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.TryStatement;
import org.aspectj.org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
import org.aspectj.org.eclipse.jdt.internal.compiler.lookup.BlockScope;

import br.upe.dsc.ehmeter.results.Measurement;
import br.upe.dsc.ehmeter.source.MetricsSource;
import br.upe.dsc.ehmeter.source.Project;
import br.upe.dsc.ehmeter.source.Type;

/**
 * Number of finally metric class.
 * */
public class NOF implements MetricsCalculator {

	public Measurement[] calculate(MetricsSource source, Project project) {
		CalculatorUtils.assertSourceIsAType(source);
		int result = countNumberOfFinally((Type)source);
		return new Measurement[] {new Measurement(Metrics.NOF, result) };
	}

	int countNumberOfFinally(Type type) {
		TypeDeclaration decl = type.getTypeDeclaration();
		
		NOTryVisitor visitor = new NOTryVisitor();
		
		decl.traverse(visitor, decl.scope);
		return visitor.getValue();
	}
	
	//Number of Try Visitor
	private static class NOTryVisitor extends ASTVisitor {
		private int value;

		public boolean visit(TryStatement tryStatement, BlockScope scope) {
			Block  block = tryStatement.finallyBlock;
			if (block != null){
				this.value++;
			}
			return super.visit(tryStatement,scope);
		};
		

		public int getValue() {
			return this.value;
		}
	}
}
