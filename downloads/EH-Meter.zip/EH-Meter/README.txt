aopmetrics

From the version 0.0.3 aopmetrics should be built using maven 2.0.x.

1. Building jar archive

mvn package


2. Building distribution bundles

mvn -Pdist

